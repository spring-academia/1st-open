CREATE TABLE books (
    id BIGINT NOT NULL,
    name VARCHAR(64),
    author VARCHAR(64)
);
