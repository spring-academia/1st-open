package com.example.mfa.security.services;

import com.example.mfa.security.datas.entities.UserEntity;

public interface UserService {
    UserEntity getUser(UserEntity userEntity);
}
