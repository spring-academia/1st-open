package com.example.metricdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetricDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
