package com.example.demo.application.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardModel {

  private String title;

  private String content;
}
