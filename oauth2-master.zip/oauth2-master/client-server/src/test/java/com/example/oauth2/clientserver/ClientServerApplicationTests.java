package com.example.oauth2.clientserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
