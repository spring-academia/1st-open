package com.example.oauth2.authorizeserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizeServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
