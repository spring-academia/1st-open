package com.example.oauth2.authorizeserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorizeServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuthorizeServerApplication.class, args);
    }

}
