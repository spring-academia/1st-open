package com.fastcampus.jpalecture.jpapeeknapply;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpapeeknapplyApplicationTests {

	@Test
	void contextLoads() {
	}

}
