INSERT INTO member(member_id, name)
VALUES ('jpa', 'alice'),
       ('spring', 'bob');
--
--/*
--INSERT INTO team(name)
--VALUES('wonder land')
--*/
