package com.fastcampus.jpalecture.jpapeeknapply;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpapeeknapplyApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpapeeknapplyApplication.class, args);
	}

}
