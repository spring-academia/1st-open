package com.fastcampus.jpalecture.jpapeeknapply.entity;

public enum GroupTypeEnum {
  ADMIN,
  USER,
}
