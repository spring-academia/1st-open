package com.fastcampus.jpalecture.jpapeeknapply.entity;

public enum UserTypeEnum {
  ADMIN,
  USER,
}
