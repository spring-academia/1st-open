package com.fastcampus.carinfo.service;

import lombok.Data;

@Data
public class CompanyInputDTO {
  private String companyName;
  private String companyNation;
}
