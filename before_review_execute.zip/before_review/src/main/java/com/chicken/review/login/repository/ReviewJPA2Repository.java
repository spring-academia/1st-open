package com.chicken.review.login.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.chicken.review.login.vo.ReviewJPAVO;

public interface ReviewJPA2Repository  extends JpaRepository<ReviewJPAVO, String>{

	List<ReviewJPAVO> findByTitleContains (String title);
}
